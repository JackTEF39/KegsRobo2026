"""A set of wrappers for board simulators to interact with Webots devices."""
